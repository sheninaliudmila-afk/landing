FINCONSULT — 11.11.2026
Распакуйте содержимое этого архива в корень хостинга своего домена. index.html должен лежать рядом с assets/ и navigator/.
Форма учебная: скачивает TXT, не отправляет заявку. Для изменения кода используйте папку source/ в репозитории https://github.com/sheninaliudmila-afk/landing
